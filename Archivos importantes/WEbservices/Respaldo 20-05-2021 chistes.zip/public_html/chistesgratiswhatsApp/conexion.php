<?php
$conexion = mysqli_connect("localhost", "id12765193_localhost", "b@V0H)-K>N9Zxo-w", "id12765193_chistes_whatsapp");
mysqli_set_charset($conexion, "utf8mb4_general_ci");

//$conn = mysql_connect($BD_SERVIDOR, $BD_USUARIO, $BD_PASSWORD);
//mysql_set_charset("UTF8", $conn);