<?php
include 'conexion.php';

try
{

	$query = "select cantidad from cant_mostrar_ad_interstitial";


			$resul = mysqli_query($conexion,$query);
			if($resul==false)
		    {
		    	$msjError = mysqli_error($conexion);
		        throw new Exception();
		    }

		    
		   		$datosArrayQuery = array();
		   		$cantidad = 0;

				while ($row = mysqli_fetch_array($resul))
				{
					 
					 $cantidad = $row['cantidad'];
											
					
				}

		   		$resultado_query = array(	
		   									'resultado'=>'OK',	
		   									'msjError'=> '',		
		   									'msjClient'=> '',
											'data'=> $cantidad
										);

				echo json_encode($resultado_query);
		  


		

}
catch(Exception $e){
	

	$resultado_query = array(
							
							'resultado'=> "ERROR",
							'msjError'=> $msjError,
							'msjClient'=>'Ocurrió un error a la hora de consultar los datos favor de contactar al programador',
							'data' => ''
						);

    echo json_encode($resultado_query);


}

?>
